#ifndef VERSION_H

#define VERSION_H

/* pkg version */
char package[] = "rancid";
char version[] = "3.7";

#endif
